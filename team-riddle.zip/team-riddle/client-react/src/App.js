import React from "react";
import  Task from "./components/Task";
import "./App.css";

function App() {
  return (
    <div className="App">
      <Task />
    </div>
  );
}

export default App;
